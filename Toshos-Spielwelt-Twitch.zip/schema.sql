PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS wallets (uid TEXT PRIMARY KEY, coins INTEGER NOT NULL DEFAULT 0 CHECK(coins>=0), version INTEGER NOT NULL DEFAULT 0, hand TEXT, receipt TEXT);
CREATE TABLE IF NOT EXISTS sessions (sid TEXT PRIMARY KEY, uid TEXT NOT NULL, name TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS redemptions (id TEXT PRIMARY KEY, uid TEXT NOT NULL, coins INTEGER NOT NULL CHECK(coins>0));
CREATE TRIGGER IF NOT EXISTS credit_redemption AFTER INSERT ON redemptions BEGIN
 INSERT INTO wallets(uid,coins) VALUES(NEW.uid,NEW.coins)
 ON CONFLICT(uid) DO UPDATE SET coins=coins+NEW.coins, version=version+1;
END;

CREATE TABLE IF NOT EXISTS commands(uid TEXT NOT NULL,id TEXT NOT NULL,response TEXT NOT NULL,PRIMARY KEY(uid,id));
CREATE TRIGGER IF NOT EXISTS store_command AFTER UPDATE OF receipt ON wallets
WHEN NEW.receipt IS NOT NULL AND NEW.receipt IS NOT OLD.receipt
BEGIN
 INSERT INTO commands(uid,id,response) VALUES(NEW.uid,json_extract(NEW.receipt,'$.id'),json_extract(NEW.receipt,'$.response'));
END;

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

