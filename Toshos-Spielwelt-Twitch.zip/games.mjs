export const stakes=[10,50,100,500];
const tiers=[
 [1,600,12,'asurd kyuubi chest w'],[1,200,6,'chakra chad susanoo rinnegan'],
 [2,80,3,'surd sharingan uchiha akatsuki'],[5,30,2,'crystal headband scroll ramen'],
 [30,20,1,'leaf kunai shuriken potion']
];
const pool=tiers.flatMap(([weight,three,two,names])=>names.split(' ').flatMap(name=>Array.from({length:weight},()=>({name,three,two}))));
export const red=[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
const ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
export function random(max){
 const value=new Uint32Array(1),limit=2**32-(2**32%max);
 do{crypto.getRandomValues(value)}while(value[0]>=limit);
 return value[0]%max;
}
export function value(cards){
 const sum=cards.reduce((total,card)=>total+card.value,0);
 return sum<=11&&cards.some(card=>card.value===1)?sum+10:sum;
}
export function publicHand(hand){
 if(!hand)return null;
 return {...hand,deck:undefined,dealer:hand.done?hand.dealer:hand.dealer.slice(0,1)};
}
export function play(wallet,command,draw=random){
 const hand=wallet.hand?JSON.parse(wallet.hand):null;
 const {action,stake,color}=command;
 const balance=wallet.coins;
 if(['slots','roulette','deal'].includes(action)){
  if(hand&&!hand.done)throw Error('Beende zuerst deine Blackjack-Runde.');
  if(!stakes.includes(stake)||stake>balance)throw Error('Nicht genug Spielmünzen für diesen Einsatz.');
  if(action==='slots'){
   const [a,b,c]=Array.from({length:3},()=>pool[draw(pool.length)]);
   const mult=a.name===b.name&&b.name===c.name?a.three:a.name===b.name||a.name===c.name?a.two:b.name===c.name?b.two:0;
   return {coins:balance-stake+stake*mult,hand:null,result:{out:[a.name,b.name,c.name],win:stake*mult}};
  }
  if(action==='roulette'){
   if(!['red','green','black'].includes(color))throw Error('Ungültige Farbe.');
   const number=draw(37),resultColor=number===0?'green':red.includes(number)?'red':'black';
   const win=color===resultColor?stake*(color==='green'?14:2):0;
   return {coins:balance-stake+win,hand:null,result:{number,color:resultColor,win}};
  }
  const deck=['♠','♥','♦','♣'].flatMap(suit=>ranks.map((rank,i)=>({suit,rank,value:Math.min(10,i+1)})));
  for(let i=deck.length-1;i>0;i--){const j=draw(i+1);[deck[i],deck[j]]=[deck[j],deck[i]]}
  const player=[deck.pop()],dealer=[deck.pop()];player.push(deck.pop());dealer.push(deck.pop());
  const next={id:command.id,turn:0,deck,player,dealer,stake,done:false,win:0,message:'Du bist am Zug.'};
  const p=value(player)===21,d=value(dealer)===21;
  if(p||d){next.done=true;next.win=p?(d?stake:stake*2.5):0;next.message=p?(d?'Beide haben Blackjack. Einsatz zurück.':'Blackjack!'):'Der Dealer hat Blackjack.'}
  return {coins:balance-stake+next.win,hand:next};
 }
 if(!hand||hand.done||!['hit','stand','double'].includes(action))throw Error('Keine passende laufende Runde.');
 if(hand.id!==command.round||hand.turn!==command.turn)throw Error('Die Blackjack-Runde hat sich geändert. Bitte aktualisieren.');
 hand.turn++;
 let coins=balance;
 if(action==='double'){
  if(hand.player.length!==2||balance<hand.stake)throw Error('Verdoppeln ist gerade nicht möglich.');
  coins-=hand.stake;hand.stake*=2;
 }
 if(action!=='stand')hand.player.push(hand.deck.pop());
 const p=value(hand.player);
 if(p>21){hand.done=true;hand.message='Überkauft. Der Dealer gewinnt.'}
 else if(action!=='hit'||p===21){
  while(value(hand.dealer)<17)hand.dealer.push(hand.deck.pop());
  const d=value(hand.dealer);hand.done=true;
  if(d>21||p>d){hand.win=hand.stake*2;hand.message=d>21?'Dealer überkauft.':'Du gewinnst!'}
  else if(p===d){hand.win=hand.stake;hand.message='Unentschieden. Einsatz zurück.'}
  else hand.message='Der Dealer gewinnt.';
 }
 return {coins:coins+hand.win,hand};
}

