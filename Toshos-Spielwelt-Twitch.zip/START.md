# Toshos Spielwelt mit Twitch-Anbindung

Die lokale HTML-Datei ist eine Übungsvorschau. Ihr Startstand liegt nur im Arbeitsspeicher und wird nie in ein Twitch-Konto übertragen. Die gehostete Version startet bei null, zieht Einsätze serverseitig ab und speichert Guthaben und laufende Blackjack-Runden in D1. Es gibt keinen Tagesbonus, keine Auszahlung und keine Rückumwandlung in Kanalpunkte.

## Vor der Freischaltung

Twitch untersagt Kanalpunkt-Einlösungen, die Glücksspiel darstellen. Klärt mit Twitch, ob ein fester Umtausch in ausschließlich virtuelle, nicht handelbare Einsatzmünzen für diese Spiele zulässig ist, bevor Tosho0 die Belohnung für Zuschauer aktiviert. Die Zustimmung des Streamers allein klärt die Plattformregeln nicht.

## Einrichtung

1. In Cloudflare mit Wrangler anmelden und die Datenbank anlegen.
   ```powershell
   npx wrangler login
   npx wrangler d1 create tosho-wallet
   ```
   Die ausgegebene Datenbank-ID in `wrangler.toml` eintragen. `PUBLIC_ORIGIN` auf die tatsächliche HTTPS-Adresse des Workers setzen. Für die Anwendung eine neue Worker-Adresse verwenden, damit die Referenzseite unverändert bleibt.
2. In der [Twitch Developer Console](https://dev.twitch.tv/console/apps) eine vertrauliche Anwendung anlegen. Als OAuth Redirect URL die exakte HTTPS-Adresse mit `/auth/callback` registrieren. Client-ID sowie Tosho0s numerische Twitch-Nutzer-ID in `wrangler.toml` eintragen. Die Nutzer-ID lässt sich über Helix Get Users mit `login=tosho0` abfragen. Kosten und Gutschrift sind auf 1.000 Kanalpunkte und 500 Spielmünzen voreingestellt und vor der Einrichtung änderbar. Optional `TWITCH_REWARD_ID` im Abschnitt `[vars]` setzen, wenn eine bestimmte bestehende Belohnung verwendet werden soll. Die Belohnung muss in die Anfragenwarteschlange gehen.
3. Das Schema anwenden, den Worker veröffentlichen und die Geheimnisse im Worker hinterlegen. Für `TWITCH_WEBHOOK_SECRET` ein zufällig generiertes Geheimnis von mindestens 32 Zeichen verwenden. Geheimnisse nur in die Wrangler-Abfragen eingeben.
   ```powershell
   npx wrangler d1 execute tosho-wallet --remote --file=schema.sql
   npx wrangler deploy
   npx wrangler secret put TWITCH_CLIENT_SECRET
   npx wrangler secret put TWITCH_WEBHOOK_SECRET
   ```
4. Tosho0 öffnet auf der Worker-Adresse `/auth/login?mode=setup` und autorisiert die Anwendung. Der Worker prüft, dass das Konto dem konfigurierten Kanal gehört, verwendet die ausgewählte Belohnung oder legt „Spielmünzen“ an und registriert den signierten EventSub-Webhook. Der Berechtigungsschritt ist dem Kanalinhaber vorbehalten.
5. Ein Zuschauer meldet sich in der Spielwelt mit seinem Twitch-Konto an und löst die Belohnung bei Tosho0 ein. Der Kanal bestätigt die Anfrage in Twitchs Belohnungswarteschlange. Nach dem bestätigten Event erscheint die Gutschrift beim selben Twitch-Konto. Mit **Aktualisieren** lässt sie sich sofort abfragen. Abgelehnte Anfragen ergeben keine Spielmünzen. Bereits vor der Webhook-Einrichtung bestätigte Anfragen werden nicht nachgetragen.

## Prüfung

Mit Node.js 24 oder neuer `node verify.mjs` ausführen. Der Test verwendet SQLite im Arbeitsspeicher, signierte Testevents und eine Testsession. Er prüft die doppelte Zustellung, abgelehnte Events, unzulässige Einsätze und veraltete Blackjack-Züge. Twitch-OAuth, Webhook-Verifikation durch Twitch und die erste echte Einlösung nach der Einrichtung einmal im tatsächlichen Deployment prüfen.

## Referenzen

- [Twitch EventSub für Kanalpunkte](https://dev.twitch.tv/docs/eventsub/reference/channel-points)
- [Twitch Channel Points Acceptable Use Policy](https://legal.twitch.com/en/legal/channel-points-acceptable-use-policy/)
- [Cloudflare Workers Static Assets](https://developers.cloudflare.com/workers/static-assets/binding/)
