import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {createHash,createHmac,randomUUID} from 'node:crypto';
import app from './worker.mjs';
import {play,publicHand,value} from './games.mjs';
const db=new DatabaseSync(':memory:');
db.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));
const env={PUBLIC_ORIGIN:'https://game.example',TWITCH_BROADCASTER_ID:'111',TWITCH_REWARD_ID:'reward-1',TWITCH_WEBHOOK_SECRET:'test-only-eventsub-signing-key',COINS_PER_REDEMPTION:'500',DB:{
 prepare(sql){return{bind(...args){return{
  first:async()=>db.prepare(sql).get(...args),run:async()=>({meta:db.prepare(sql).run(...args)})
 }},first:async()=>db.prepare(sql).get()}}
}};
const fetchApp=(path,init)=>app.fetch(new Request(env.PUBLIC_ORIGIN+path,init),env);
const topic='channel.channel_points_custom_reward_redemption.update';
const subscription={type:topic,condition:{broadcaster_user_id:'111',reward_id:'reward-1'}};
async function webhook(body,type='notification',sign=true){
 const raw=JSON.stringify({subscription,...body}),id=randomUUID(),timestamp=new Date().toISOString();
 const sig=createHmac('sha256',sign?env.TWITCH_WEBHOOK_SECRET:'wrong').update(id+timestamp+raw).digest('hex');
 return fetchApp('/twitch/eventsub',{method:'POST',body:raw,headers:{
  'Twitch-Eventsub-Message-Id':id,'Twitch-Eventsub-Message-Timestamp':timestamp,
  'Twitch-Eventsub-Message-Signature':'sha256='+sig,'Twitch-Eventsub-Message-Type':type
 }});
}
const event={id:'redeem-1',user_id:'222',broadcaster_user_id:'111',status:'fulfilled',reward:{id:'reward-1'}};
const balance=()=>db.prepare("SELECT coins FROM wallets WHERE uid='222'").get()?.coins??0;
assert.equal(await (await webhook({challenge:'challenge-value'},'webhook_callback_verification')).text(),'challenge-value');
assert.equal((await webhook({event},'notification',false)).status,403);
assert.equal((await webhook({event:{...event,status:'canceled'}})).status,204);
assert.equal(balance(),0);
assert.equal((await webhook({event})).status,204);
assert.equal((await webhook({event})).status,204);
assert.equal(balance(),500);
const sid=randomUUID();
db.prepare('INSERT INTO sessions VALUES(?,?,?,?)').run(createHash('sha256').update(sid).digest('hex'),'222','Test',Date.now()+100000);
const headers={Cookie:'tosho_sid='+sid,Origin:env.PUBLIC_ORIGIN,'Content-Type':'application/json'};
const request=command=>fetchApp('/api/play',{method:'POST',headers,body:JSON.stringify(command)});
const first={action:'roulette',stake:10,color:'red',id:randomUUID()};
const second={...first,id:randomUUID()};
assert.equal((await request(first)).status,200);
assert.equal((await request(second)).status,200);
const after=balance();
assert.equal((await request(first)).status,200);
assert.equal(balance(),after);
assert.equal((await request({...first,stake:1,id:randomUUID()})).status,409);
const card=value=>({value});
assert.equal(value([card(1),card(1),card(9)]),21);
const next=play({coins:500,hand:null},{action:'deal',stake:100,id:'test'},max=>max-1);
assert.equal(next.coins,400);
assert.equal(publicHand(next.hand).dealer.length,1);
assert.equal(publicHand(next.hand).deck,undefined);
assert.throws(()=>play({coins:400,hand:JSON.stringify(next.hand)},{action:'hit',round:'wrong',turn:0}));
const stood=play({coins:400,hand:JSON.stringify(next.hand)},{action:'stand',round:'test',turn:0});
assert.equal(stood.hand.done,true);
console.log('PASS: signed challenge, invalid signature, rejected redemption, deduplicated credit, session, old game retry, allowed stakes, private blackjack hand and stale turn');
