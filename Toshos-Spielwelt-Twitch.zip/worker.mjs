import {play,publicHand} from './games.mjs';

const json=(body,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
const origin=env=>new URL(env.PUBLIC_ORIGIN).origin;
const cookie=(name,value,age)=>name+'='+value+'; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age='+age;
const cookies=req=>Object.fromEntries((req.headers.get('cookie')||'').split(';').map(c=>c.trim().split('=')));
const hash=async value=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)));
const hex=bytes=>Array.from(new Uint8Array(bytes),n=>n.toString(16).padStart(2,'0')).join('');
function redirect(path,headers={}){
 return new Response(null,{status:303,headers:{Location:path,'Cache-Control':'no-store',...headers}});
}
async function token(fields,env){
 const body=new URLSearchParams({...fields,client_id:env.TWITCH_CLIENT_ID,client_secret:env.TWITCH_CLIENT_SECRET});
 const res=await fetch('https://id.twitch.tv/oauth2/token',{method:'POST',body});
 if(!res.ok)throw Error('Twitch-Tokenanfrage fehlgeschlagen.');
 return (await res.json()).access_token;
}
async function helix(path,access,env,body){
 const res=await fetch('https://api.twitch.tv/helix/'+path,{
  method:body?'POST':'GET',
  headers:{'Client-Id':env.TWITCH_CLIENT_ID,Authorization:'Bearer '+access,'Content-Type':'application/json'},
  body:body?JSON.stringify(body):undefined
 });
 if(!res.ok)throw Error('Twitch-API fehlgeschlagen (HTTP '+res.status+').');
 return (await res.json()).data;
}
const topic='channel.channel_points_custom_reward_redemption.update';
async function rewardId(env){
 if(env.TWITCH_REWARD_ID)return env.TWITCH_REWARD_ID;
 const entry=await env.DB.prepare("SELECT value FROM settings WHERE key='reward_id'").first();
 return entry?.value;
}
async function setup(access,env){
 const query=new URLSearchParams({broadcaster_id:env.TWITCH_BROADCASTER_ID});
 const configured=await rewardId(env);
 const rewards=await helix('channel_points/custom_rewards?'+query,access,env);
 let reward=configured?rewards.find(r=>r.id===configured):rewards.find(r=>r.title.toLowerCase()==='spielmünzen');
 if(configured&&!reward)throw Error('Die eingestellte Kanalbelohnung wurde nicht gefunden.');
 if(!reward){
  const cost=Number(env.REWARD_CHANNEL_POINTS_COST);
  if(!Number.isSafeInteger(cost)||cost<1||cost>1e9)throw Error('Ungültige Kanalpunktekosten.');
  [reward]=await helix('channel_points/custom_rewards?'+query,access,env,{
   title:'Spielmünzen',cost,prompt:'Nach Bestätigung wird deinem Konto ein fester Betrag virtueller Spielmünzen gutgeschrieben.',
   background_color:'#7937AF',should_redemptions_skip_request_queue:false
  });
 }
 if(reward.should_redemptions_skip_request_queue)throw Error('Die Twitch-Belohnung muss die Anfragenwarteschlange verwenden.');
 await env.DB.prepare("INSERT INTO settings(key,value) VALUES('reward_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind(reward.id).run();
 const app=await token({grant_type:'client_credentials'},env);
 const condition={broadcaster_user_id:env.TWITCH_BROADCASTER_ID,reward_id:reward.id};
 const callback=origin(env)+'/twitch/eventsub';
 const existing=await helix('eventsub/subscriptions?type='+topic,app,env);
 if(!existing.some(s=>['enabled','webhook_callback_verification_pending'].includes(s.status)&&
  s.condition.reward_id===condition.reward_id&&s.condition.broadcaster_user_id===condition.broadcaster_user_id&&s.transport.callback===callback)){
  await helix('eventsub/subscriptions',app,env,{type:topic,version:'1',condition,transport:{method:'webhook',callback,secret:env.TWITCH_WEBHOOK_SECRET}});
 }
}
async function eventsub(req,env){
 const id=req.headers.get('Twitch-Eventsub-Message-Id');
 const timestamp=req.headers.get('Twitch-Eventsub-Message-Timestamp');
 const signature=req.headers.get('Twitch-Eventsub-Message-Signature')||'';
 const type=req.headers.get('Twitch-Eventsub-Message-Type');
 if(!id||!Number.isFinite(Date.parse(timestamp))||Math.abs(Date.now()-Date.parse(timestamp))>600000||!/^sha256=[a-f0-9]{64}$/.test(signature))return json({error:'Ungültiges Event.'},403);
 const raw=await req.text(),enc=new TextEncoder();
 const key=await crypto.subtle.importKey('raw',enc.encode(env.TWITCH_WEBHOOK_SECRET),{name:'HMAC',hash:'SHA-256'},false,['verify']);
 const bytes=Uint8Array.from(signature.slice(7).match(/../g),s=>parseInt(s,16));
 if(!await crypto.subtle.verify('HMAC',key,bytes,enc.encode(id+timestamp+raw)))return json({error:'Signatur ungültig.'},403);
 const body=JSON.parse(raw),subscription=body.subscription,idReward=await rewardId(env);
 if(subscription?.type!==topic||!idReward||subscription.condition?.reward_id!==idReward||
  subscription.condition.broadcaster_user_id!==env.TWITCH_BROADCASTER_ID)return json({error:'Unbekanntes Abonnement.'},403);
 if(type==='webhook_callback_verification')return new Response(body.challenge,{headers:{'Content-Type':'text/plain'}});
 const event=body.event;
 if(type==='notification'&&event?.status==='fulfilled'&&event.reward?.id===idReward&&
  event.broadcaster_user_id===env.TWITCH_BROADCASTER_ID&&typeof event.id==='string'&&/^\d+$/.test(event.user_id)){
  const amount=Number(env.COINS_PER_REDEMPTION);
  if(!Number.isSafeInteger(amount)||amount<=0)throw Error('COINS_PER_REDEMPTION fehlt.');
  await env.DB.prepare('INSERT OR IGNORE INTO redemptions(id,uid,coins) VALUES(?,?,?)').bind(event.id,event.user_id,amount).run();
 }
 return new Response(null,{status:204});
}
async function session(req,env){
 const sid=cookies(req).tosho_sid;
 if(!sid||!/^[-\da-f]{36}$/.test(sid))return null;
 return env.DB.prepare('SELECT uid,name FROM sessions WHERE sid=? AND expires>?').bind(await hash(sid),Date.now()).first();
}
const wallet=(db,uid)=>db.prepare('SELECT coins,version,hand,receipt FROM wallets WHERE uid=?').bind(uid).first();
async function route(req,env){
 const url=new URL(req.url),path=url.pathname;
 if(path==='/twitch/eventsub'&&req.method==='POST')return eventsub(req,env);
 if(path==='/auth/login'&&req.method==='GET'){
  const owner=url.searchParams.get('mode')==='setup';
  const state=(owner?'setup.':'view.')+crypto.randomUUID();
  const fields=new URLSearchParams({client_id:env.TWITCH_CLIENT_ID,redirect_uri:origin(env)+'/auth/callback',response_type:'code',state});
  fields.set('scope',owner?'channel:manage:redemptions':'');
  return redirect('https://id.twitch.tv/oauth2/authorize?'+fields,{'Set-Cookie':cookie('tosho_oauth',state,600)});
 }
 if(path==='/auth/callback'&&req.method==='GET'){
  const state=url.searchParams.get('state'),code=url.searchParams.get('code');
  if(!state||state!==cookies(req).tosho_oauth||!code)return json({error:'Twitch-Anmeldung abgebrochen oder abgelaufen.'},403);
  const access=await token({grant_type:'authorization_code',code,redirect_uri:origin(env)+'/auth/callback'},env);
  const [user]=await helix('users',access,env);
  if(state.startsWith('setup.')){
   if(user.id!==env.TWITCH_BROADCASTER_ID)return json({error:'Nur der Kanalinhaber kann EventSub verbinden.'},403);
   await setup(access,env);
   return redirect('/?twitch=verbunden',{'Set-Cookie':cookie('tosho_oauth','',0)});
  }
  const sid=crypto.randomUUID(),lifetime=86400;
  await env.DB.batch([
   env.DB.prepare('DELETE FROM sessions WHERE expires<=?').bind(Date.now()),
   env.DB.prepare('INSERT OR IGNORE INTO wallets(uid) VALUES(?)').bind(user.id),
   env.DB.prepare('INSERT INTO sessions(sid,uid,name,expires) VALUES(?,?,?,?)').bind(await hash(sid),user.id,user.display_name,Date.now()+lifetime*1000)
  ]);
  const result=redirect('/',{'Set-Cookie':cookie('tosho_sid',sid,lifetime)});
  result.headers.append('Set-Cookie',cookie('tosho_oauth','',0));return result;
 }
 if(path==='/api/session'&&req.method==='GET'){
  const user=await session(req,env);
  if(!user)return json({user:null});
  const account=await wallet(env.DB,user.uid);
  return json({user:user.name,coins:account.coins,hand:publicHand(account.hand?JSON.parse(account.hand):null)});
 }
 if(path==='/api/play'&&req.method==='POST'){
  if(req.headers.get('Origin')!==origin(env))return json({error:'Ungültiger Ursprung.'},403);
  const user=await session(req,env);
  if(!user)return json({error:'Melde dich zuerst mit Twitch an.'},401);
  const command=await req.json();
  if(!command||!/^[-\da-f]{36}$/.test(command.id))return json({error:'Ungültige Anfrage.'},400);
  for(let attempt=0;attempt<4;attempt++){
   const account=await wallet(env.DB,user.uid);
   const receipt=await env.DB.prepare('SELECT response FROM commands WHERE uid=? AND id=?').bind(user.uid,command.id).first();
   if(receipt)return json({...JSON.parse(receipt.response),coins:account.coins});
   let next;
   try{next=play(account,command)}catch(error){return json({error:error.message},409)}
   const response={coins:next.coins,hand:publicHand(next.hand),result:next.result};
   const update=await env.DB.prepare('UPDATE wallets SET coins=?,hand=?,receipt=?,version=version+1 WHERE uid=? AND version=?')
    .bind(next.coins,next.hand?JSON.stringify(next.hand):null,JSON.stringify({id:command.id,response}),user.uid,account.version).run();
   if(update.meta.changes===1)return json(response);
  }
  return json({error:'Dein Guthaben hat sich gleichzeitig geändert. Bitte erneut versuchen.'},409);
 }
 if(path==='/auth/logout'&&req.method==='POST'&&req.headers.get('Origin')===origin(env)){
  const sid=cookies(req).tosho_sid;
  if(sid)await env.DB.prepare('DELETE FROM sessions WHERE sid=?').bind(await hash(sid)).run();
  return redirect('/',{'Set-Cookie':cookie('tosho_sid','',0)});
 }
 return env.ASSETS.fetch(req);
}
export default {async fetch(req,env){
 try{return await route(req,env)}catch(error){
  console.error(error.message);
  return json({error:'Die Spielwelt konnte die Anfrage gerade nicht verarbeiten.'},500);
 }
}};




